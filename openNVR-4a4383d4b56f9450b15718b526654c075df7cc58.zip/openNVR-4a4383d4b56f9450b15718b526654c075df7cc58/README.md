openNVR
=======

an open source NVR(Network Video Recorder) implementation, which focus on ONVIF/PSIA/RTSP IPC management, live video relay/record, multi-node(server) cluster, video replay. It is the distributed recording solution for IP-based video surveillance.
